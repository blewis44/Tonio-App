import './globals.css';

export const metadata = {
  title: 'Tour Ops Dashboard',
  description: 'Tour routing and itinerary planner',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
