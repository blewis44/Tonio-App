'use client';

import React, { useMemo, useState } from 'react';

const starterShows = [
  {
    id: 1,
    date: '2026-04-01',
    city: 'Orlando',
    venue: 'Rosen Shingle Creek',
    airport: 'MCO',
    status: 'Ready',
    hotel: 'Rosen Shingle Creek',
    ground: 'Uber',
    showTime: '7:30–8:30 PM',
  },
  {
    id: 2,
    date: '2026-04-10',
    city: 'Nashville',
    venue: 'TBD',
    airport: 'BNA',
    status: 'Pending',
    hotel: 'JW Marriott Nashville',
    ground: 'Uber',
    showTime: 'TBD',
  },
  {
    id: 3,
    date: '2026-04-11',
    city: 'Arlington',
    venue: 'College Park Center',
    airport: 'DFW',
    status: 'Ready',
    hotel: 'Live! by Loews Arlington',
    ground: 'Uber',
    showTime: 'TBD',
  },
  {
    id: 4,
    date: '2026-05-22',
    city: 'Clarksville',
    venue: 'Wilma Rudolph Event Center',
    airport: 'BNA',
    status: 'Needs promoter hotel',
    hotel: 'Promoter-provided 5★ hotel',
    ground: 'Sprinter',
    showTime: 'TBD',
  },
];

const cityAirportMap = {
  Orlando: 'MCO',
  Nashville: 'BNA',
  Arlington: 'DFW',
  Dallas: 'DFW',
  Columbus: 'ATL',
  Gretna: 'TLH',
  Oklahoma: 'OKC',
  'Oklahoma City': 'OKC',
  Meridian: 'JAN',
  Clarksville: 'BNA',
  Harvest: 'HSV',
  Chattanooga: 'CHA',
  'Little Rock': 'LIT',
  Atlanta: 'ATL',
  West: 'DFW',
  Hampton: 'ORF',
};

const hotelSuggestions = {
  Orlando: 'Rosen Shingle Creek',
  Nashville: 'JW Marriott Nashville',
  Arlington: 'Live! by Loews Arlington',
  Clarksville: 'Promoter-provided 5★ hotel',
  Chattanooga: 'The Westin Chattanooga',
  Atlanta: 'Renaissance Atlanta Airport Gateway',
  Hampton: 'Embassy Suites Hampton Convention Center',
};

function formatShortDate(date) {
  const d = new Date(date + 'T12:00:00');
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function dateDiffInDays(a, b) {
  const ms = new Date(b + 'T12:00:00') - new Date(a + 'T12:00:00');
  return Math.round(ms / (1000 * 60 * 60 * 24));
}

function computeRoutedShows(shows) {
  const sorted = [...shows].sort((a, b) => a.date.localeCompare(b.date));
  return sorted.map((show, index) => {
    if (index === 0) {
      return { ...show, origin: 'RDU', route: `RDU → ${show.airport || 'TBD'}` };
    }
    const prev = sorted[index - 1];
    const gap = dateDiffInDays(prev.date, show.date);
    const isBackToBack = gap <= 2;
    const origin = isBackToBack ? prev.airport || prev.city : 'RDU';
    return { ...show, origin, route: `${origin} → ${show.airport || 'TBD'}`, gap, isBackToBack };
  });
}

function parseBulkLine(line, id) {
  const parts = line.split('—').map((p) => p.trim()).filter(Boolean);
  const [datePart, cityPart, venuePart, timePart] = parts;
  if (!datePart || !cityPart) return null;
  const normalizedCity = cityPart.replace(/,.*$/, '').trim();
  const airport = cityAirportMap[normalizedCity] || 'TBD';
  return {
    id,
    date: new Date(datePart).toISOString().slice(0, 10),
    city: normalizedCity,
    venue: venuePart || 'TBD',
    airport,
    status: 'Pending',
    hotel: hotelSuggestions[normalizedCity] || '4★+ hotel TBD',
    ground: normalizedCity === 'Clarksville' ? 'Sprinter' : 'Uber',
    showTime: timePart || 'TBD',
  };
}

export default function Home() {
  const [shows, setShows] = useState(starterShows);
  const [selectedId, setSelectedId] = useState(1);
  const [filter, setFilter] = useState('All');
  const [form, setForm] = useState({ date: '', city: '', venue: '', airport: '', showTime: '' });
  const [bulkInput, setBulkInput] = useState(
    'Apr 10 2026 — Nashville — TBD — 7:00 PM\nApr 11 2026 — Arlington — College Park Center — TBD\nMay 1 2026 — Gretna — Springfield Multipurpose Center — TBD'
  );

  const routedShows = useMemo(() => computeRoutedShows(shows), [shows]);
  const filteredShows = useMemo(() => filter === 'All' ? routedShows : routedShows.filter((show) => show.status === filter), [routedShows, filter]);
  const selectedShow = routedShows.find((s) => s.id === selectedId) || routedShows[0];

  const cards = useMemo(() => {
    const nextShow = routedShows[0];
    const pendingFlights = routedShows.filter((s) => s.status !== 'Ready').length;
    const hotelActions = routedShows.filter((s) => s.hotel.toLowerCase().includes('promoter') || s.status.includes('hotel')).length;
    const driveLegs = routedShows.filter((s) => ['Sprinter', 'Drive'].includes(s.ground)).length;
    return [
      { title: 'Next Show', value: nextShow ? `${nextShow.city} · ${formatShortDate(nextShow.date)}` : 'None', sub: nextShow ? `${nextShow.showTime} · ${nextShow.hotel}` : 'No show loaded' },
      { title: 'Flights To Book', value: String(pendingFlights), sub: 'Back-to-back legs auto-route from the previous city' },
      { title: 'Hotel Actions', value: String(hotelActions), sub: 'Promoter-covered or manual hotel follow-up needed' },
      { title: 'Ground Plans', value: String(driveLegs), sub: 'Sprinter or drive legs flagged automatically' },
    ];
  }, [routedShows]);

  function handleAddShow(e) {
    e.preventDefault();
    if (!form.date || !form.city) return;
    const normalizedCity = form.city.trim();
    const airport = form.airport || cityAirportMap[normalizedCity] || 'TBD';
    const newShow = {
      id: Date.now(),
      date: form.date,
      city: normalizedCity,
      venue: form.venue || 'TBD',
      airport,
      status: 'Pending',
      hotel: hotelSuggestions[normalizedCity] || '4★+ hotel TBD',
      ground: normalizedCity === 'Clarksville' ? 'Sprinter' : 'Uber',
      showTime: form.showTime || 'TBD',
    };
    setShows((prev) => [...prev, newShow]);
    setSelectedId(newShow.id);
    setForm({ date: '', city: '', venue: '', airport: '', showTime: '' });
  }

  function handleBulkImport() {
    const lines = bulkInput.split('\n').map((line) => line.trim()).filter(Boolean);
    const parsed = lines.map((line, idx) => parseBulkLine(line, Date.now() + idx)).filter(Boolean);
    if (!parsed.length) return;
    setShows((prev) => {
      const merged = [...prev, ...parsed];
      return merged.filter((show, index, arr) => arr.findIndex((s) => `${s.date}-${s.city}-${s.venue}` === `${show.date}-${show.city}-${show.venue}`) === index);
    });
    setSelectedId(parsed[0].id);
  }

  function handleStatusChange(id, status) {
    setShows((prev) => prev.map((show) => (show.id === id ? { ...show, status } : show)));
  }

  return (
    <div className="page-shell">
      <div className="container">
        <div className="hero">
          <div>
            <div className="eyebrow">Tour Ops Dashboard</div>
            <h1>Tonio Armani Travel Planner</h1>
            <p>Add shows, auto-route flights from previous cities when dates are back-to-back, and generate a clean itinerary view for the team.</p>
          </div>
          <div className="hero-buttons">
            <button className="button secondary">Save Draft</button>
            <button className="button primary">Generate Itinerary</button>
          </div>
        </div>

        <div className="card-grid">
          {cards.map((card) => (
            <div key={card.title} className="card stat-card">
              <div className="card-label">{card.title}</div>
              <div className="card-value">{card.value}</div>
              <div className="card-sub">{card.sub}</div>
            </div>
          ))}
        </div>

        <div className="main-grid">
          <div className="card table-card">
            <div className="card-header between">
              <div>
                <h2>Tour Routing</h2>
                <p>If the next show is within 2 days, flight origin becomes the previous show city. Otherwise it resets to RDU.</p>
              </div>
              <div className="filter-wrap">
                <label>Filter</label>
                <select value={filter} onChange={(e) => setFilter(e.target.value)}>
                  <option>All</option>
                  <option>Ready</option>
                  <option>Pending</option>
                  <option>Needs promoter hotel</option>
                  <option>Booked</option>
                </select>
              </div>
            </div>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>City</th>
                    <th>Venue</th>
                    <th>Flight Route</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredShows.map((show) => (
                    <tr key={show.id} className={selectedShow?.id === show.id ? 'active-row' : ''} onClick={() => setSelectedId(show.id)}>
                      <td>{formatShortDate(show.date)}</td>
                      <td><strong>{show.city}</strong></td>
                      <td>{show.venue}</td>
                      <td>{show.route}</td>
                      <td>
                        <select value={show.status} onChange={(e) => handleStatusChange(show.id, e.target.value)} onClick={(e) => e.stopPropagation()}>
                          <option>Ready</option>
                          <option>Pending</option>
                          <option>Needs promoter hotel</option>
                          <option>Booked</option>
                        </select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="card intake-card">
            <div className="card-header">
              <div>
                <h2>Quick Intake</h2>
                <p>Add a single show or paste multiple shows at once.</p>
              </div>
            </div>
            <form onSubmit={handleAddShow} className="form-stack">
              <input placeholder="Date" type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
              <input placeholder="City" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
              <input placeholder="Venue" value={form.venue} onChange={(e) => setForm({ ...form, venue: e.target.value })} />
              <div className="two-col">
                <input placeholder="Airport" value={form.airport} onChange={(e) => setForm({ ...form, airport: e.target.value.toUpperCase() })} />
                <input placeholder="Show time" value={form.showTime} onChange={(e) => setForm({ ...form, showTime: e.target.value })} />
              </div>
              <button className="button primary" type="submit">Add Show</button>
            </form>
            <div className="divider" />
            <div className="bulk-section">
              <div className="bulk-title">Bulk import</div>
              <textarea value={bulkInput} onChange={(e) => setBulkInput(e.target.value)} />
              <button className="button secondary full" onClick={handleBulkImport}>Import Shows</button>
            </div>
          </div>
        </div>

        <div className="bottom-grid">
          <div className="card">
            <div className="card-header"><h3>Flight Options</h3></div>
            <div className="list-stack">
              {[
                [selectedShow?.route || 'RDU → TBD', '$214', 'Best overall'],
                [selectedShow?.route || 'RDU → TBD', '$248', 'Flexible timing'],
                [selectedShow?.route || 'RDU → TBD', '$189', 'Budget option'],
              ].map((f) => (
                <div key={f.join('-')} className="info-row between">
                  <div>
                    <div className="info-title">{f[0]}</div>
                    <div className="info-sub">{f[2]}</div>
                  </div>
                  <div className="price-block">
                    <div className="price">{f[1]}</div>
                    <div className="small-muted">Book link</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="card">
            <div className="card-header"><h3>Hotel Picks</h3></div>
            <div className="list-stack">
              {[
                [selectedShow?.hotel || '4★+ hotel TBD', '4★+', '0.6 mi to venue'],
                ['Backup option', '4★', '1.1 mi to venue'],
                ['Promoter / manual option', 'Custom', 'Needs confirmation'],
              ].map((h) => (
                <div key={h.join('-')} className="info-row">
                  <div className="info-title">{h[0]}</div>
                  <div className="info-sub">{h[1]} · {h[2]}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="card">
            <div className="card-header"><h3>Itinerary Share</h3></div>
            <div className="share-box">
              <div><strong>Trip:</strong> {selectedShow?.city || '—'}</div>
              <div><strong>Venue:</strong> {selectedShow?.venue || '—'}</div>
              <div><strong>Show Time:</strong> {selectedShow?.showTime || '—'}</div>
              <div><strong>Ground:</strong> {selectedShow?.ground || '—'}</div>
              <div><strong>Status:</strong> {selectedShow?.status || '—'}</div>
            </div>
            <div className="button-stack">
              <button className="button secondary full">Copy Share Link</button>
              <button className="button secondary full">Export PDF</button>
              <button className="button primary full">Send to Team</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
